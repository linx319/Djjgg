package lol.lwes.ss.gui.clickgui;

import lol.lwes.ss.module.Module;

record SuggestionRect(Module module, float x, float y, float width, float height) {
}
