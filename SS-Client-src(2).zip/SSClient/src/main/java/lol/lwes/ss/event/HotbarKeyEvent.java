package lol.lwes.ss.event;

import lol.lwes.ss.SSClient;

public class HotbarKeyEvent extends KeyBindingEvent {
    private final int slot;

    public HotbarKeyEvent(int i) {
        super(SSClient.mc.options.hotbarKeys[i]);
        this.slot = i;
    }

    public int getSlot() {
        return this.slot;
    }
}
