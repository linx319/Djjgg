package lol.lwes.ss.util;

import java.util.Objects;

public record FileEntry(String name, String path, String sha1) {
    @Override
    public final boolean equals(Object object) {
        return this == object
            || object instanceof FileEntry fileentry1
                && Objects.equals(this.sha1, fileentry1.sha1)
                && Objects.equals(this.path, fileentry1.path)
                && Objects.equals(this.name, fileentry1.name);
    }

    @Override
    public final String toString() {
        return "ik[" + "aU=" + this.name + ", aV=" + this.path + ", aW=" + this.sha1 + "]";
    }

    @Override
    public final int hashCode() {
        int i = 0 + Objects.hashCode(this.name);
        i = i * 31 + Objects.hashCode(this.path);
        return i * 31 + Objects.hashCode(this.sha1);
    }
}
