package lol.lwes.ss.event;

public class BlockBreakStartEvent extends BlockBreakEvent {
    private static final BlockBreakStartEvent INSTANCE = new BlockBreakStartEvent();

    public static BlockBreakStartEvent getInstance() {
        return INSTANCE;
    }
}
