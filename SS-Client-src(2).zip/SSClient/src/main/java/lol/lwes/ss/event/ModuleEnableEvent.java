package lol.lwes.ss.event;

import lol.lwes.ss.module.Module;

public class ModuleEnableEvent extends Event {
    public Module module;

    public ModuleEnableEvent(Module module) {
        this.module = module;
    }

    public Module getModule() {
        return this.module;
    }
}
