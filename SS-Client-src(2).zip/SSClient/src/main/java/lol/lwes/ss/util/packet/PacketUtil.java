package lol.lwes.ss.util.packet;

import lol.lwes.ss.SSClient;
import lol.lwes.ss.mixin.accessor.ClientWorldAccessor;
import net.minecraft.client.network.PendingUpdateManager;
import net.minecraft.client.network.SequencedPacketCreator;
import net.minecraft.network.packet.Packet;

public class PacketUtil {
    public static void sendSequenced(SequencedPacketCreator sequencedpacketcreator) {
        if (SSClient.mc.getNetworkHandler() != null && SSClient.mc.world != null) {
            try (PendingUpdateManager pendingupdatemanager = ((ClientWorldAccessor)SSClient.mc.world).getPendingUpdateManager().incrementSequence()) {
                int i = pendingupdatemanager.getSequence();
                SSClient.mc.getNetworkHandler().sendPacket(sequencedpacketcreator.predict(i));
            }
        }
    }

    public static void sendImmediate(Packet packet) {
        SSClient.mc.getNetworkHandler().getConnection().send(packet, null);
    }

    public static void sendPacket(Packet packet) {
        if (SSClient.mc.player != null) {
            SSClient.mc.getNetworkHandler().sendPacket(packet);
        }
    }
}
