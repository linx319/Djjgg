package lol.lwes.ss.util;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import lol.lwes.ss.SSClient;
import lol.lwes.ss.gui.NotificationManager;
import lol.lwes.ss.module.Module;
import lol.lwes.ss.util.CrashEntry;

public class CrashHandler {
    public static final List crashLog = Collections.synchronizedList(new ArrayList());

    public static void handleModuleCrash(Module module, Throwable throwable) {
        ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
        throwable.printStackTrace(new PrintStream(bytearrayoutputstream));
        crashLog.add(new CrashEntry(module.getName(), bytearrayoutputstream.toString(), System.currentTimeMillis()));
        Module.LOGGER.error("[{}] Exception in module, disabling", module.getName(), throwable);

        try {
            module.forceDisable();
        } catch (Throwable throwable1) {
            Module.LOGGER.error("[{}] Failed to disable", module.getName(), throwable1);
        }

        NotificationManager notificationmanager = SSClient.getNotifications();
        String s = module.getName();
        String s2 = s + " disabled due to crash";
        String s3 = "Crash Handler";
        notificationmanager.addNotification(s3, s2);
    }
}
