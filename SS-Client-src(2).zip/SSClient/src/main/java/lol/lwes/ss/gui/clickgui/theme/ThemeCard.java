package lol.lwes.ss.gui.clickgui.theme;

import lol.lwes.ss.config.ThemePreset;

public record ThemeCard(ThemePreset preset, int x, int y, int width, int height) {
    public boolean contains(double mouseX, double mouseY) {
        return mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= this.y && mouseY <= this.y + this.height;
    }
}
