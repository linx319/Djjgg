package lol.lwes.ss.util;

public class EmptyMarker {
}
