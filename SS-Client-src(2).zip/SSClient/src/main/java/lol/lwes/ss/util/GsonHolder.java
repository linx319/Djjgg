package lol.lwes.ss.util;

import com.google.gson.Gson;

public class GsonHolder {
    public static Gson GSON = new Gson();
}
