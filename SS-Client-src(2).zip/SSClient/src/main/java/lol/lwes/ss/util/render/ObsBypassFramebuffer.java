package lol.lwes.ss.util.render;

import lol.lwes.ss.util.render.shader.FramebufferBlitRenderer;

public class ObsBypassFramebuffer extends FramebufferBlitRenderer {
    public boolean useDefaultFramebuffer;

    @Override
    protected int getTextureId() {
        return this.useDefaultFramebuffer ? 0 : RenderManager.getCurrentFramebuffer();
    }
}
