package lol.lwes.ss.event;

public class MotionEvent extends Event {
}
