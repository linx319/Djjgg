package lol.lwes.ss.util.rotation;

public enum RotationAxisMode {
    YawAndPitch,
    Yaw,
    Pitch;

    private static RotationAxisMode[] $values() {
        return new RotationAxisMode[]{YawAndPitch, Yaw, Pitch};
    }
}
