package lol.lwes.ss.event;

public class WorldJoinEvent extends Event {
}
