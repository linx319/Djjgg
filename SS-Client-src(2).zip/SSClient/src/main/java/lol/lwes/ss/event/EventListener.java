package lol.lwes.ss.event;

public interface EventListener {
    void invoke(Object[] aobject);

    boolean isStatic();

    Class getEventType();

    int getPriority();

    Object getInstance();

    void invoke(Object object);
}
