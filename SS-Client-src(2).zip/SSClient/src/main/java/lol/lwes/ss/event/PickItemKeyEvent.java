package lol.lwes.ss.event;

import lol.lwes.ss.SSClient;

public class PickItemKeyEvent extends KeyBindingEvent {
    public PickItemKeyEvent() {
        super(SSClient.mc.options.pickItemKey);
    }
}
