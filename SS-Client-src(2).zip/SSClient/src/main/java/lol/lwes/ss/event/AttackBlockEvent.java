package lol.lwes.ss.event;

public class AttackBlockEvent extends AttackEvent {
    private static final AttackBlockEvent INSTANCE = new AttackBlockEvent();

    public static AttackBlockEvent getInstance() {
        return INSTANCE;
    }
}
