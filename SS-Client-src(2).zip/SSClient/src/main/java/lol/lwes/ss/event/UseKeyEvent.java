package lol.lwes.ss.event;

import lol.lwes.ss.SSClient;

public class UseKeyEvent extends KeyBindingEvent {
    public UseKeyEvent() {
        super(SSClient.mc.options.useKey);
    }
}
