package lol.lwes.ss.util.inventory;

public enum SwapMode {
    SWAP_THEN_ACTION,
    ACTION_THEN_SWAP
}
