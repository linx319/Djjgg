package lol.lwes.ss.util.prediction;

public interface MotionPredictor {
    MotionResult predict(MotionRequest motionrequest);
}
