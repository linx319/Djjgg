package lol.lwes.ss.event;

public class UseEvent extends Event {
}
