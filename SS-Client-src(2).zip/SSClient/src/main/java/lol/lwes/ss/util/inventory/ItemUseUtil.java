package lol.lwes.ss.util.inventory;

import java.util.function.Predicate;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

/** Uses an item once (offhand first, then hotbar), optionally at a fixed pitch, then restores slot and pitch. */
public final class ItemUseUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private ItemUseUtil() {
    }

    public static boolean useItem(Item item, Float pitch) {
        return useItem(stack -> stack.isOf(item), pitch);
    }

    public static boolean useItem(Predicate<ItemStack> predicate, Float pitch) {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.interactionManager == null) {
            return false;
        }

        Hand hand;
        int previousSlot = -1;
        if (predicate.test(player.getOffHandStack())) {
            hand = Hand.OFF_HAND;
        } else {
            FoundSlot found = InventoryUtil.findHotbarStack(predicate);
            if (!found.isFound()) {
                return false;
            }

            previousSlot = player.getInventory().getSelectedSlot();
            InventoryUtil.selectSlot(found.getSlot());
            hand = Hand.MAIN_HAND;
        }

        if (player.getItemCooldownManager().isCoolingDown(player.getStackInHand(hand))) {
            if (previousSlot >= 0) {
                InventoryUtil.selectSlot(previousSlot);
            }

            return false;
        }

        float oldPitch = player.getPitch();
        if (pitch != null) {
            player.setPitch(pitch);
        }

        ActionResult result = mc.interactionManager.interactItem(player, hand);
        if (result instanceof ActionResult.Success success && success.swingSource() == ActionResult.SwingSource.CLIENT) {
            player.swingHand(hand);
        }

        if (pitch != null) {
            player.setPitch(oldPitch);
        }

        if (previousSlot >= 0) {
            InventoryUtil.selectSlot(previousSlot);
        }

        return true;
    }
}
