package lol.lwes.ss.util.inventory;

public record PendingSwap(int slot, int delay, Runnable callback) {
}
