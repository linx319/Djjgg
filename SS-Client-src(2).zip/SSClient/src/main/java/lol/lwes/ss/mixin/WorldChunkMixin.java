package lol.lwes.ss.mixin;

import lol.lwes.ss.hook.BlockStateHook;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.WorldChunk;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(WorldChunk.class)
public abstract class WorldChunkMixin {
    @Shadow
    @Final
    private World world;

    @Inject(method = "setBlockState", at = @At("RETURN"))
    private void onSetBlockState(BlockPos blockpos, BlockState blockstate, int i, CallbackInfoReturnable callbackinforeturnable) {
        BlockStateHook.onSetBlockState(this.world, blockpos, blockstate, callbackinforeturnable);
    }
}
