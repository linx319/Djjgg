package lol.lwes.ss.event;

public class PostItemUseEvent extends Event {
    private static final PostItemUseEvent INSTANCE = new PostItemUseEvent();

    public static PostItemUseEvent getInstance() {
        INSTANCE.setCancelled(false);
        return INSTANCE;
    }

    public boolean wasCancelled() {
        return this.isCancelled();
    }
}
