package lol.lwes.ss.util;

import com.google.common.hash.Hashing;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipOutputStream;
import lol.lwes.ss.SSClient;
import lol.lwes.ss.api.ApiClient;
import lol.lwes.ss.config.ConfigManager;
import lol.lwes.ss.event.EventHandler;
import lol.lwes.ss.event.TickEvent;
import lol.lwes.ss.util.FileEntry;
import net.fabricmc.loader.impl.FabricLoaderImpl;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.world.ClientWorld;

public class CrashReporter {
    private static String currentWorld = "";
    private static String currentServer = "";
    private static final int MAX_FILE_SIZE = 20480;
    public static void collectAndSendReport(String s, String s1) throws Throwable {
        Path path = Paths.get("");
        String s2 = Files.readString(path.resolve("logs").resolve("latest.log"));
        String s3 = Files.readString(path.resolve("options.txt"));
        ArrayList arraylist = new ArrayList();
        ArrayList arraylist1 = new ArrayList(CrashHandler.crashLog);
        JsonObject jsonobject = ConfigManager.serializeModules();
        ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
        Iterator iterator = Files.list(FabricLoaderImpl.INSTANCE.getModsDirectory().toPath()).iterator();

        while (iterator.hasNext()) {
            File file1 = ((Path)iterator.next()).toFile();
            String s4 = null;

            try {
                s4 = com.google.common.io.Files.asByteSource(file1).hash(Hashing.sha512()).toString();
            } catch (IOException ioexception1) {
            }

            String s5 = null;

            try {
                s5 = com.google.common.io.Files.asByteSource(file1).hash(Hashing.sha1()).toString();
            } catch (IOException ioexception) {
            }

            arraylist.add(new FileEntry(file1.getName(), s4, s5));
        }

        ArrayList<String> arraylist4 = new ArrayList<>();

        for (String s14 : jsonobject.keySet()) {
            JsonObject jsonobject2 = jsonobject.get(s14).getAsJsonObject();
            if (jsonobject2.get("enabled").getAsBoolean()) {
                jsonobject2.remove("key");
            } else {
                arraylist4.add(s14);
            }
        }

        for (String s15 : arraylist4) {
            jsonobject.remove(s15);
        }

        try (ZipOutputStream zipoutputstream = new ZipOutputStream(bytearrayoutputstream)) {
            Path path1 = path.resolve("config");
            String s17 = path1.toAbsolutePath().toString();
            char c0 = File.separatorChar;
            String s6 = s17;
            String s16 = s6 + c0;
            Files.walkFileTree(path1, new ZipFileVisitor(zipoutputstream, s16));
        }

        String s18 = currentServer;
        String s19 = currentWorld;
        byte[] abyte = bytearrayoutputstream.toByteArray();
        String s8 = s3;
        JsonObject jsonobject1 = jsonobject;
        ArrayList arraylist2 = arraylist;
        ArrayList arraylist3 = arraylist1;
        String s9 = s19;
        String s10 = s18;
        String s11 = s2;
        String s12 = s1;
        String s13 = s;
        sendReport(s13, s12, s11, s10, s9, arraylist3, arraylist2, jsonobject1, s8, abyte);
    }

    public static void sendReport(String s, String s1, String s2, String s3, String s4, List list, List list1, JsonObject jsonobject, String s5, byte[] abyte) throws IOException {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        JsonObject jsonobject1 = new JsonObject();
        jsonobject1.addProperty("type", s);
        jsonobject1.addProperty("crash", s1);
        jsonobject1.addProperty("log", s2);
        jsonobject1.addProperty("server", s3);
        jsonobject1.addProperty("world", s4);
        jsonobject1.addProperty("modules", gson.toJson(list));
        jsonobject1.addProperty("hashes", gson.toJson(list1));
        jsonobject1.addProperty("options", s5);
        jsonobject1.add("ss", jsonobject);
        jsonobject1.addProperty("config", Base64.getEncoder().encodeToString(abyte));
        ApiClient apiclient = ApiClient.INSTANCE;
        String s6 = readFile(gson.toJson(jsonobject1));
        apiclient.sendCrashReport(s6);
    }

    private static String readFile(String s) {
        try {
            ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();

            try (GZIPOutputStream gzipoutputstream = new GZIPOutputStream(bytearrayoutputstream)) {
                gzipoutputstream.write(s.getBytes(StandardCharsets.UTF_8));
            }

            return Base64.getEncoder().encodeToString(bytearrayoutputstream.toByteArray());
        } catch (IOException ioexception) {
            return "";
        }
    }

    public static int getMaxFileSize() {
        return MAX_FILE_SIZE;
    }

    @EventHandler
    public static void onUpdate(TickEvent tickevent) {
        Optional.ofNullable(SSClient.mc.world).map(clientworld -> String.valueOf(clientworld.getRegistryKey().getValue())).ifPresent(s -> currentWorld = s);
        Optional.ofNullable(SSClient.mc.getNetworkHandler())
            .map(ClientPlayNetworkHandler::getServerInfo)
            .map(serverinfo -> serverinfo.address)
            .ifPresent(s -> currentServer = s);
    }
}
