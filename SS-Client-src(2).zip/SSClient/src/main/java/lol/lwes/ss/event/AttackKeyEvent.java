package lol.lwes.ss.event;

import lol.lwes.ss.SSClient;

public class AttackKeyEvent extends KeyBindingEvent {
    public AttackKeyEvent() {
        super(SSClient.mc.options.attackKey);
    }

    public static int getDefaultPriority() {
        return 110;
    }

    public static int getEventId() {
        return 0;
    }
}
