package lol.lwes.ss.util.render;

public interface EasingFunction {
    float apply(float f);
}
