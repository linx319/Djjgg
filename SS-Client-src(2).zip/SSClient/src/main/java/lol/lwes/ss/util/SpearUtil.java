package lol.lwes.ss.util;

import lol.lwes.ss.mixin.accessor.MinecraftClientAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

public final class SpearUtil {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private SpearUtil() {
    }

    /** Any "<material>_spear" item. */
    public static boolean isSpear(ItemStack stack) {
        return !stack.isEmpty() && Registries.ITEM.getId(stack.getItem()).getPath().endsWith("_spear");
    }

    public static boolean isMace(ItemStack stack) {
        return stack.isOf(net.minecraft.item.Items.MACE);
    }

    /** Attacks (jabs) with whatever is in your main hand, like a left click. */
    public static boolean jab() {
        return ((MinecraftClientAccessor)mc).invokeDoAttack();
    }
}
