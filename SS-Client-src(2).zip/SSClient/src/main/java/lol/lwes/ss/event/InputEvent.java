package lol.lwes.ss.event;

import lol.lwes.ss.SSClient;
import net.minecraft.client.input.Input;

public class InputEvent extends Event {
    public MovementInput input;
    public boolean localPlayer;

    public InputEvent(Input input) {
        this.input = MovementInput.fromInput(input);
        this.localPlayer = SSClient.mc.player != null && input == SSClient.mc.player.input;
    }
}
