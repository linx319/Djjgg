package lol.lwes.ss.util;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZipFileVisitor implements FileVisitor {
    final ZipOutputStream zip;
    final String basePath;

    ZipFileVisitor(ZipOutputStream zipoutputstream, String s) {
        this.zip = zipoutputstream;
        this.basePath = s;
    }

    public FileVisitResult visitFile(Path path) throws IOException {
        byte[] abyte = Files.readAllBytes(path);
        if (null == null) {
            if (abyte.length >= CrashReporter.getMaxFileSize()) {
                return FileVisitResult.CONTINUE;
            }

            this.zip.putNextEntry(new ZipEntry(path.toAbsolutePath().toString().replace(this.basePath, "")));
        }

        this.zip.write(abyte);
        return FileVisitResult.CONTINUE;
    }

    public FileVisitResult postVisitDirectory() throws IOException {
        return FileVisitResult.CONTINUE;
    }

    public FileVisitResult visitFileFailed() throws IOException {
        return FileVisitResult.CONTINUE;
    }

    public FileVisitResult a() throws IOException {
        return FileVisitResult.CONTINUE;
    }

    @Override
    public FileVisitResult visitFile(Object object, BasicFileAttributes basicfileattributes) throws IOException {
        return this.visitFile((Path)object);
    }

    @Override
    public FileVisitResult visitFileFailed(Object object, IOException ioexception) throws IOException {
        return this.visitFileFailed();
    }

    @Override
    public FileVisitResult preVisitDirectory(Object object, BasicFileAttributes basicfileattributes) throws IOException {
        return this.a();
    }

    @Override
    public FileVisitResult postVisitDirectory(Object object, IOException ioexception) throws IOException {
        return this.postVisitDirectory();
    }
}
