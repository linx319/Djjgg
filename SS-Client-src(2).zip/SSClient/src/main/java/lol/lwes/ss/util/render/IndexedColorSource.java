package lol.lwes.ss.util.render;

public interface IndexedColorSource {
    int getGlyphColor2(int i, int j);
}
