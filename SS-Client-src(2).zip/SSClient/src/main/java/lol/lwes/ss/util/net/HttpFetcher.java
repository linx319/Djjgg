package lol.lwes.ss.util.net;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.MultiThreadIoEventLoopGroup;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.nio.NioIoHandler;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.http.DefaultFullHttpRequest;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpClientCodec;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaderValues;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpVersion;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

public final class HttpFetcher {
    private static final int CONNECT_TIMEOUT_MS = 10000;
    private static final long REQUEST_TIMEOUT_MS = 15000L;
    private static final int MAX_RESPONSE_BYTES = 1 << 20;

    private HttpFetcher() {
    }

    public static String get(String url, Consumer<ChannelPipeline> pipelineCustomizer) {
        if (url == null) {
            return "";
        }

        try {
            return request(URI.create(url), pipelineCustomizer);
        } catch (Exception exception) {
            return "";
        }
    }

    private static String request(URI uri, Consumer<ChannelPipeline> pipelineCustomizer) throws Exception {
        String scheme = uri.getScheme() == null ? "http" : uri.getScheme().toLowerCase();
        boolean secure = scheme.equals("https");
        String host = uri.getHost();
        if (host == null) {
            throw new IllegalArgumentException("URL has no host: " + uri);
        }

        int port = uri.getPort() != -1 ? uri.getPort() : (secure ? 443 : 80);
        String path = uri.getRawPath() == null || uri.getRawPath().isEmpty() ? "/" : uri.getRawPath();
        if (uri.getRawQuery() != null) {
            path = path + "?" + uri.getRawQuery();
        }

        SslContext sslContext = secure ? SslContextBuilder.forClient().build() : null;
        CompletableFuture<String> result = new CompletableFuture<>();
        EventLoopGroup group = new MultiThreadIoEventLoopGroup(1, NioIoHandler.newFactory());

        try {
            Bootstrap bootstrap = new Bootstrap()
                .group(group)
                .channel(NioSocketChannel.class)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, CONNECT_TIMEOUT_MS)
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel channel) {
                        ChannelPipeline pipeline = channel.pipeline();
                        pipeline.addLast("codec", new HttpClientCodec());
                        pipeline.addLast("aggregator", new HttpObjectAggregator(MAX_RESPONSE_BYTES));
                        pipeline.addLast("handler", new ResponseHandler(result));
                        if (pipelineCustomizer != null) {
                            pipelineCustomizer.accept(pipeline);
                        }
                    }
                });

            ChannelFuture connect = bootstrap.connect(host, port);
            String requestPath = path;
            connect.addListener(future -> {
                if (!future.isSuccess()) {
                    result.completeExceptionally(future.cause());
                    return;
                }

                Channel channel = connect.channel();
                if (sslContext != null) {
                    channel.pipeline().addFirst("ssl", sslContext.newHandler(channel.alloc(), host, port));
                }

                FullHttpRequest request = new DefaultFullHttpRequest(HttpVersion.HTTP_1_1, HttpMethod.GET, requestPath);
                request.headers().set(HttpHeaderNames.HOST, port == (secure ? 443 : 80) ? host : host + ":" + port);
                request.headers().set(HttpHeaderNames.CONNECTION, HttpHeaderValues.CLOSE);
                request.headers().set(HttpHeaderNames.USER_AGENT, "SS");
                request.headers().set(HttpHeaderNames.ACCEPT, "*/*");
                channel.writeAndFlush(request);
            });

            try {
                return result.get(REQUEST_TIMEOUT_MS, TimeUnit.MILLISECONDS).trim();
            } finally {
                connect.channel().close();
            }
        } finally {
            group.shutdownGracefully(0L, 1L, TimeUnit.SECONDS);
        }
    }

    private static final class ResponseHandler extends SimpleChannelInboundHandler<FullHttpResponse> {
        private final CompletableFuture<String> result;

        ResponseHandler(CompletableFuture<String> result) {
            this.result = result;
        }

        @Override
        protected void channelRead0(ChannelHandlerContext ctx, FullHttpResponse response) {
            int status = response.status().code();
            if (status >= 200 && status < 300) {
                this.result.complete(response.content().toString(StandardCharsets.UTF_8));
            } else {
                this.result.completeExceptionally(new IllegalStateException("HTTP " + status));
            }
            ctx.close();
        }

        @Override
        public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
            this.result.completeExceptionally(cause);
            ctx.close();
        }

        @Override
        public void channelInactive(ChannelHandlerContext ctx) throws Exception {
            this.result.completeExceptionally(new IllegalStateException("Connection closed before a response was received"));
            super.channelInactive(ctx);
        }
    }
}
