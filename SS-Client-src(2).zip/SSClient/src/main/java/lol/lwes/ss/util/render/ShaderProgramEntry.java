package lol.lwes.ss.util.render;

public class ShaderProgramEntry {
    private final String name;

    public ShaderProgramEntry(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
