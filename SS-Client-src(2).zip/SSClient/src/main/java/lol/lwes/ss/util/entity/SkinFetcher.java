package lol.lwes.ss.util.entity;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.yggdrasil.ProfileResult;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import lol.lwes.ss.SSClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.Util;

public final class SkinFetcher {
    private static final Map<String, CompletableFuture<Optional<SkinTextures>>> CACHE = new ConcurrentHashMap<>();

    private SkinFetcher() {
    }

    public static SkinTextures getSkinTextures(String name) {
        if (name == null || name.trim().isEmpty()) {
            return null;
        }

        String playerName = name.trim();
        CompletableFuture<Optional<SkinTextures>> future = CACHE.computeIfAbsent(playerName.toLowerCase(Locale.ROOT), key -> fetch(playerName));
        return future.getNow(Optional.empty()).orElse(null);
    }

    public static void clearCache() {
        CACHE.clear();
    }

    private static CompletableFuture<Optional<SkinTextures>> fetch(String name) {
        MinecraftClient mc = SSClient.mc;
        return CompletableFuture.supplyAsync(() -> resolveProfile(mc, name), Util.getDownloadWorkerExecutor())
            .thenCompose(profile -> profile.isPresent() ? mc.getSkinProvider().fetchSkinTextures(profile.get()) : CompletableFuture.completedFuture(Optional.<SkinTextures>empty()))
            .exceptionally(throwable -> Optional.empty());
    }

    private static Optional<GameProfile> resolveProfile(MinecraftClient mc, String name) {
        Optional<GameProfile> byName = mc.getApiServices().profileResolver().getProfileByName(name);
        if (byName.isEmpty()) {
            return Optional.empty();
        }

        GameProfile profile = byName.get();
        if (!profile.properties().isEmpty()) {
            return byName;
        }

        ProfileResult result = mc.getApiServices().sessionService().fetchProfile(profile.id(), false);
        return result != null ? Optional.of(result.profile()) : byName;
    }
}
