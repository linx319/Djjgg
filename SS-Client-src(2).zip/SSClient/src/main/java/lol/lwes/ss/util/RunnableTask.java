package lol.lwes.ss.util;

public interface RunnableTask {
    void run();
}
