package lol.lwes.ss.util.render;

import java.util.ArrayDeque;
import lol.lwes.ss.SSClient;
import lol.lwes.ss.config.ClientSettings;
import lol.lwes.ss.config.ThemeProperty;
import org.lwjgl.glfw.GLFW;

public class GuiScale {
    private static final ArrayDeque scaleStack = new ArrayDeque();
    private static float overrideScale = -1.0F;
    private static float lockedScale = -1.0F;

    private GuiScale() {
    }

    public static float getScaledWidth() {
        return isScaleOverridden() ? SSClient.mc.getWindow().getFramebufferWidth() / overrideScale : SSClient.mc.getWindow().getScaledWidth();
    }

    private static float getScaleSetting(ThemeProperty themeproperty) {
        Object object = themeproperty.getValue();
        float f = object instanceof Number ? ((Number)object).floatValue() : 100.0F;
        return Math.max(0.25F, f / 100.0F);
    }

    public static void popScale() {
        overrideScale = scaleStack.isEmpty() ? -1.0F : (Float)scaleStack.pop();
    }

    public static boolean isScaleOverridden() {
        return overrideScale > 0.0F;
    }

    public static float getGuiHeight() {
        return SSClient.mc.getWindow().getFramebufferHeight() / getGuiScale();
    }

    public static boolean isVanillaScale() {
        Object object = ClientSettings.followMcScale.getValue();
        return object instanceof Boolean && (Boolean)object;
    }

    public static float getScaledHeight() {
        return isScaleOverridden() ? SSClient.mc.getWindow().getFramebufferHeight() / overrideScale : SSClient.mc.getWindow().getScaledHeight();
    }

    public static float getGuiScale() {
        if (isVanillaScale()) {
            return getWindowScaleFactor();
        }

        ThemeProperty themeproperty = ClientSettings.hudScale;
        return 2.0F * getScaleSetting(themeproperty);
    }

    public static float getEffectiveScale() {
        return isScaleOverridden() ? overrideScale : getWindowScaleFactor();
    }

    public static void pushScale(float f) {
        scaleStack.push(overrideScale);
        overrideScale = f;
    }

    public static float getGuiWidth() {
        return SSClient.mc.getWindow().getFramebufferWidth() / getGuiScale();
    }

    public static double toGuiUnits(double d0, float f) {
        return d0 * getWindowScaleFactor() / f;
    }

    public static int opaqueZero() {
        return 0;
    }

    private static float getLockedScale() {
        if (GLFW.glfwGetMouseButton(SSClient.mc.getWindow().getHandle(), 0) != 1 || lockedScale < 0.0F) {
            ThemeProperty themeproperty = ClientSettings.guiScale;
            lockedScale = getScaleSetting(themeproperty);
        }

        return lockedScale;
    }

    public static float getWindowScaleFactor() {
        return SSClient.mc.getWindow().getScaleFactor();
    }

    public static float getAutoScale(float f, float f1) {
        float f2 = isVanillaScale() ? getWindowScaleFactor() : 2.0F * getLockedScale();
        float f3 = SSClient.mc.getWindow().getFramebufferWidth() / f;
        float f4 = SSClient.mc.getWindow().getFramebufferHeight() / f1;
        return Math.min(f2, Math.min(f3, f4));
    }
}
