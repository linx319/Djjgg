package lol.lwes.ss.event;

public class HookEvent {
    public String name;
}
