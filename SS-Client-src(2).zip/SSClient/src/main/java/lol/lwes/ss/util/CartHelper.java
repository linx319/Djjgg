package lol.lwes.ss.util;

import java.util.function.Predicate;
import lol.lwes.ss.util.inventory.FoundSlot;
import lol.lwes.ss.util.inventory.InventoryUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Rail / TNT minecart / enemy lookup helpers shared by AutoCart, AutoSafeCart and CartAura. */
public final class CartHelper {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private CartHelper() {
    }

    public static boolean isRailItem(ItemStack stack) {
        return stack.isOf(Items.RAIL) || stack.isOf(Items.POWERED_RAIL) || stack.isOf(Items.DETECTOR_RAIL) || stack.isOf(Items.ACTIVATOR_RAIL);
    }

    public static boolean isRail(BlockPos pos) {
        return mc.world != null && mc.world.getBlockState(pos).isIn(BlockTags.RAILS);
    }

    public static boolean inReach(BlockPos pos) {
        double reach = mc.player.getBlockInteractionRange();
        return mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) <= reach * reach;
    }

    public static boolean isReplaceable(BlockPos pos) {
        return mc.world.getBlockState(pos).isReplaceable();
    }

    /** A hit on the given face of a block, aimed at the middle of that face. */
    public static BlockHitResult hitOn(BlockPos pos, Direction face) {
        Vec3d hit = Vec3d.ofCenter(pos).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
        return new BlockHitResult(hit, face, pos, false);
    }

    /** Finds a solid neighbour of {@code pos} to place against. */
    public static BlockHitResult placementHit(BlockPos pos) {
        for (Direction direction : Direction.values()) {
            BlockPos neighbour = pos.offset(direction);
            if (!mc.world.getBlockState(neighbour).isReplaceable() && !mc.world.getBlockState(neighbour).isAir()) {
                return hitOn(neighbour, direction.getOpposite());
            }
        }

        return null;
    }

    public static boolean useOnBlock(Hand hand, BlockHitResult hit) {
        ActionResult result = mc.interactionManager.interactBlock(mc.player, hand, hit);
        if (result instanceof ActionResult.Success success) {
            if (success.swingSource() == ActionResult.SwingSource.CLIENT) {
                mc.player.swingHand(hand);
            }

            return true;
        }

        return false;
    }

    public static boolean place(BlockPos pos, Predicate<ItemStack> item) {
        if (!isReplaceable(pos) || !inReach(pos)) {
            return false;
        }

        BlockHitResult hit = placementHit(pos);
        if (hit == null) {
            return false;
        }

        Hand hand;
        int previous = -1;
        if (item.test(mc.player.getMainHandStack())) {
            hand = Hand.MAIN_HAND;
        } else if (item.test(mc.player.getOffHandStack())) {
            hand = Hand.OFF_HAND;
        } else {
            FoundSlot slot = InventoryUtil.findHotbarStack(item);
            if (!slot.isFound()) {
                return false;
            }

            previous = InventoryUtil.getSelectedSlot();
            InventoryUtil.selectSlot(slot.getSlot());
            hand = Hand.MAIN_HAND;
        }

        boolean placed = useOnBlock(hand, hit);
        if (previous >= 0) {
            InventoryUtil.selectSlot(previous);
        }

        return placed;
    }

    public static boolean placeRail(BlockPos pos) {
        return place(pos, CartHelper::isRailItem);
    }

    /** Places a TNT minecart on the rail at {@code railPos}. */
    public static boolean placeCart(BlockPos railPos) {
        FoundSlot slot = InventoryUtil.findHotbarStack(stack -> stack.isOf(Items.TNT_MINECART));
        if (!slot.isFound() || !inReach(railPos)) {
            return false;
        }

        int previous = InventoryUtil.getSelectedSlot();
        InventoryUtil.selectSlot(slot.getSlot());
        boolean placed = useOnBlock(Hand.MAIN_HAND, hitOn(railPos, Direction.UP));
        InventoryUtil.selectSlot(previous);
        return placed;
    }

    public static boolean isEnemyPlayer(Entity entity) {
        return entity instanceof PlayerEntity player
            && player != mc.player
            && player.isAlive()
            && !player.isSpectator()
            && !PlayerTargetUtil.isFriend(player.getUuid());
    }

    public static PlayerEntity nearestEnemy(Vec3d from, double range) {
        PlayerEntity best = null;
        double bestDistance = range * range;
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (!isEnemyPlayer(player)) {
                continue;
            }

            double distance = new Vec3d(player.getX(), player.getY(), player.getZ()).squaredDistanceTo(from);
            if (distance <= bestDistance) {
                bestDistance = distance;
                best = player;
            }
        }

        return best;
    }

    public static PlayerEntity nearestEnemy(double range) {
        return nearestEnemy(new Vec3d(mc.player.getX(), mc.player.getY(), mc.player.getZ()), range);
    }

    public static void attack(Entity entity) {
        mc.interactionManager.attackEntity(mc.player, entity);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
