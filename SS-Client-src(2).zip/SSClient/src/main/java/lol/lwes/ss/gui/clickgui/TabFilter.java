package lol.lwes.ss.gui.clickgui;

public enum TabFilter {
    RECOMMENDED,
    ALL;

    private static TabFilter[] $values() {
        return new TabFilter[]{RECOMMENDED, ALL};
    }
}
