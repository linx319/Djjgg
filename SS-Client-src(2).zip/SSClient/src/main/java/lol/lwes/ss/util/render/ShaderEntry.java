package lol.lwes.ss.util.render;

public class ShaderEntry {
    private final String name;

    public ShaderEntry(String s) {
        this.name = s;
    }

    public String getName() {
        return this.name;
    }
}
