package lol.lwes.ss.event;

public class ShutdownEvent extends Event {
    private static final ShutdownEvent INSTANCE = new ShutdownEvent();

    private ShutdownEvent() {
    }

    public static ShutdownEvent getInstance() {
        return INSTANCE;
    }
}
