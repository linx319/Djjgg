package lol.lwes.ss.util.render;

import dev.prestigeclient.renderlib.impl.render.resource.GlTexture;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Locale;

public final class ServerIconCache {
    private static final String ICON_ENDPOINT = "https://api.mcsrvstat.us/icon/";
    private static final byte[] NO_ICON = new byte[0];
    private static final HttpClient HTTP = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(5))
        .followRedirects(HttpClient.Redirect.NORMAL)
        .build();
    private static final DynamicTextureCache ICONS = new DynamicTextureCache(address -> fetch((String)address));

    private ServerIconCache() {
    }

    public static GlTexture getIcon(String address) {
        String key = normalize(address);
        return key == null ? null : ICONS.getTexture(key);
    }

    public static void invalidate(String address) {
        String key = normalize(address);
        if (key != null) {
            ICONS.remove(key);
        }
    }

    public static void clear() {
        ICONS.clear();
    }

    private static String normalize(String address) {
        if (address == null) {
            return null;
        }

        String trimmed = address.trim().toLowerCase(Locale.ROOT);
        return trimmed.isEmpty() ? null : trimmed;
    }

    private static void fetch(String address) {
        HttpRequest request;
        try {
            request = HttpRequest.newBuilder(URI.create(ICON_ENDPOINT + URLEncoder.encode(address, StandardCharsets.UTF_8)))
                .timeout(Duration.ofSeconds(10))
                .header("User-Agent", "SS-Client")
                .GET()
                .build();
        } catch (IllegalArgumentException exception) {
            ICONS.putData(address, NO_ICON);
            return;
        }

        HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofByteArray()).whenComplete((response, throwable) -> {
            if (throwable == null && response.statusCode() == 200 && response.body() != null && response.body().length > 0) {
                ICONS.putData(address, response.body());
            } else {
                ICONS.putData(address, NO_ICON);
            }
        });
    }
}
