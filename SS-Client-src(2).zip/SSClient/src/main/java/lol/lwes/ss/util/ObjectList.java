package lol.lwes.ss.util;

import java.util.ArrayList;

public class ObjectList extends ArrayList {
}
