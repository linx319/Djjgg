package lol.lwes.ss.event;

public class PreRenderEvent {
    private static final PreRenderEvent INSTANCE = new PreRenderEvent();

    public static PreRenderEvent getInstance() {
        return INSTANCE;
    }
}
