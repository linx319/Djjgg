package lol.lwes.ss.util.inventory;

/** Swaps to a hotbar slot for a few ticks, then back to the slot you started on. */
public class TimedSwap {
    private int previous = -1;
    private int ticksLeft;

    public void swapTo(int slot, int ticks) {
        int selected = InventoryUtil.getSelectedSlot();
        if (selected < 0) {
            return;
        }

        if (this.previous < 0) {
            this.previous = selected;
        }

        if (slot != selected) {
            InventoryUtil.selectSlot(slot);
        }

        this.ticksLeft = ticks;
    }

    public void tick() {
        if (this.previous >= 0 && this.ticksLeft-- <= 0) {
            this.restore();
        }
    }

    public void restore() {
        if (this.previous >= 0 && InventoryUtil.getSelectedSlot() >= 0) {
            InventoryUtil.selectSlot(this.previous);
        }

        this.previous = -1;
    }
}
