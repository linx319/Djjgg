package lol.lwes.ss.gui.clickgui.component;

public enum ThresholdKind {
    FALL,
    HEALTH;

    public boolean isFall() {
        return this == FALL;
    }
}
