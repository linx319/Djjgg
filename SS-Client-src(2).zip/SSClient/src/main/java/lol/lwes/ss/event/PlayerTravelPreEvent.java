package lol.lwes.ss.event;

import net.minecraft.util.math.Vec3d;

public class PlayerTravelPreEvent extends PlayerTravelEvent {
    public PlayerTravelPreEvent(Vec3d vec3d) {
        super(vec3d);
    }
}
