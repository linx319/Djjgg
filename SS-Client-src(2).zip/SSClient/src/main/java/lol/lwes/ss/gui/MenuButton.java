package lol.lwes.ss.gui;

public record MenuButton(String label, Runnable action) {
    public void press() {
        if (this.action != null) {
            this.action.run();
        }
    }
}
