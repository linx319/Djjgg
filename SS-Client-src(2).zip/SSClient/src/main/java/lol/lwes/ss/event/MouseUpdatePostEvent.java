package lol.lwes.ss.event;

public class MouseUpdatePostEvent extends MouseUpdateEvent {
    public MouseUpdatePostEvent(double d0, double d1) {
        super(d0, d1);
    }
}
