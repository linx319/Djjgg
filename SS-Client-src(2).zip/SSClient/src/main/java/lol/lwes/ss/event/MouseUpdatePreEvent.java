package lol.lwes.ss.event;

public class MouseUpdatePreEvent extends MouseUpdateEvent {
    public MouseUpdatePreEvent(double d0, double d1) {
        super(d0, d1);
    }
}
