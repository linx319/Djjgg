package lol.lwes.ss.event;

public class InputsHeadEvent {
    private static final InputsHeadEvent INSTANCE = new InputsHeadEvent();

    public static InputsHeadEvent getInstance() {
        return INSTANCE;
    }
}
