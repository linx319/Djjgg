package lol.lwes.ss.util.proxy;

public enum ProxyType {
    SOCKS4,
    HTTP,
    SOCKS5
}
