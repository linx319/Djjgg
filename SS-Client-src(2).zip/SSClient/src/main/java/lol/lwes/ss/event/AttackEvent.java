package lol.lwes.ss.event;

public class AttackEvent extends Event {
}
