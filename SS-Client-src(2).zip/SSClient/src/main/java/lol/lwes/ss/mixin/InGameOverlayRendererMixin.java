package lol.lwes.ss.mixin;

import lol.lwes.ss.hook.InGameOverlayRendererHooks;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public abstract class InGameOverlayRendererMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
    private static void onRenderFireOverlay(MatrixStack matrixstack, VertexConsumerProvider vertexconsumerprovider, Sprite sprite, CallbackInfo callbackinfo) {
        InGameOverlayRendererHooks.onRenderFireOverlay(matrixstack, vertexconsumerprovider, sprite, callbackinfo);
    }
}
