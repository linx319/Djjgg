package lol.lwes.ss.event;

public class BlockBreakEvent extends Event {
}
