package lol.lwes.ss.util.inventory;

import java.util.ArrayDeque;
import lol.lwes.ss.SSClient;
import lol.lwes.ss.event.EventHandler;
import lol.lwes.ss.event.TickEvent;

public class SwapScheduler {
    public static final ArrayDeque PENDING_SWAPS = new ArrayDeque();

    public static void clearQueue() {
        PENDING_SWAPS.clear();
    }

    public static SwapBuilder newSwap() {
        return new SwapBuilder();
    }

    @EventHandler
    public void tick(TickEvent tickevent) {
        if (!PENDING_SWAPS.isEmpty() && SSClient.mc.player != null) {
            int i = PENDING_SWAPS.size();

            for (int j = 0; j < i; j++) {
                PendingSwap pendingswap = (PendingSwap)PENDING_SWAPS.poll();
                if (pendingswap.delay() > 1) {
                    ArrayDeque arraydeque = PENDING_SWAPS;
                    int k = pendingswap.delay();
                    arraydeque.add(new PendingSwap(pendingswap.slot(), k - 1, pendingswap.callback()));
                } else {
                    int l = pendingswap.slot();
                    InventoryUtil.selectSlot(l);
                    if (pendingswap.callback() != null) {
                        pendingswap.callback().run();
                    }
                }
            }
        }
    }
}
