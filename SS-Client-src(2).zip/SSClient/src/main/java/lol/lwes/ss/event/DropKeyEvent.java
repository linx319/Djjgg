package lol.lwes.ss.event;

import lol.lwes.ss.SSClient;

public class DropKeyEvent extends KeyBindingEvent {
    public DropKeyEvent() {
        super(SSClient.mc.options.inventoryKey);
    }
}
