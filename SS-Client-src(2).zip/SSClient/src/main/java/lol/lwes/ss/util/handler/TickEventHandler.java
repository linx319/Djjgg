package lol.lwes.ss.util.handler;

import lol.lwes.ss.event.TaskExecuteEvent;

public interface TickEventHandler extends HandlerNode {
    default TickEventHandler applyTick(TaskExecuteEvent taskexecuteevent) {
        TickHandlerTransformer tickhandlertransformer = TickHandlerTransformer.INSTANCE;
        return (TickEventHandler)this.applyTransformer((HandlerTransformer)tickhandlertransformer, taskexecuteevent, true);
    }

    default TickEventHandler getDefaultTickHandler() {
        return null;
    }

    default TickEventHandler getTickHandler(TaskExecuteEvent taskexecuteevent) {
        return this.getDefaultTickHandler();
    }

    boolean hasTickHandler();
}
