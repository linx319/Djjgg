package lol.lwes.ss;

import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import java.util.List;
import lol.lwes.ss.api.ApiClient;
import lol.lwes.ss.config.HudLayout;
import lol.lwes.ss.event.DefaultEventBus;
import lol.lwes.ss.event.EventBus;
import lol.lwes.ss.gui.NotificationManager;
import lol.lwes.ss.input.KeybindHandler;
import lol.lwes.ss.module.ModuleManager;
import lol.lwes.ss.script.ScriptManager;
import lol.lwes.ss.util.CrashReporter;
import lol.lwes.ss.util.PlayerTargetUtil;
import lol.lwes.ss.util.ReleaseNotes;
import lol.lwes.ss.util.SoundPlayer;
import lol.lwes.ss.util.TickFastForward;
import lol.lwes.ss.util.combat.SpinAttackController;
import lol.lwes.ss.util.font.FontManager;
import lol.lwes.ss.util.input.KeySimulator;
import lol.lwes.ss.util.input.MouseSimulator;
import lol.lwes.ss.util.inventory.SwapScheduler;
import lol.lwes.ss.util.media.MediaController;
import lol.lwes.ss.util.packet.ReceivedPacketQueue;
import lol.lwes.ss.util.packet.SentPacketQueue;
import lol.lwes.ss.util.render.ShaderRegistry;
import lol.lwes.ss.util.rotation.RotationManager;
import lol.lwes.ss.util.rotation.SmoothRotationController;
import lol.lwes.ss.util.target.TargetManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.Packet;
import net.minecraft.resource.ResourceType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SSClient implements ModInitializer {
    public static final String NAME = "SS Client";
    public static final String COMMAND_PREFIX = ".";
    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);
    public static final List<Packet<?>> silentPackets = new ArrayList<>();

    public static SSClient instance;
    public static MinecraftClient mc;
    public static EventBus eventBus;
    public static FontManager fonts;

    public HudLayout hudLayout;
    public RotationManager rotationManager;
    public SmoothRotationController rotationController;
    public NotificationManager notifications;
    public SoundPlayer soundPlayer;
    public PlayerTargetUtil playerTargets;
    public ScriptManager scriptManager;
    public KeybindHandler keybindHandler;
    public ShaderRegistry shaderRegistry;
    public MediaController mediaController;
    public ReleaseNotes releaseNotes;
    public SpinAttackController spinAttackController;
    public boolean disabled;

    private MouseSimulator mouseSimulator;
    private KeySimulator keySimulator;

    @Override
    public void onInitialize() {
        instance = this;
        mc = MinecraftClient.getInstance();
        eventBus = new DefaultEventBus();
        eventBus.registerLookupProvider("lol.lwes", (lookupIn, owner) -> (MethodHandles.Lookup) lookupIn.invoke(null, owner, MethodHandles.lookup()));

        fonts = new FontManager();
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(fonts);
        ShaderRegistry.registerReloadListener();

        hudLayout = new HudLayout();
        rotationManager = new RotationManager();
        rotationController = new SmoothRotationController();
        notifications = new NotificationManager();
        soundPlayer = new SoundPlayer();
        playerTargets = new PlayerTargetUtil();
        scriptManager = new ScriptManager();
        keybindHandler = new KeybindHandler();
        shaderRegistry = new ShaderRegistry();
        mediaController = new MediaController();
        releaseNotes = new ReleaseNotes();
        spinAttackController = new SpinAttackController();
        mouseSimulator = new MouseSimulator();
        keySimulator = new KeySimulator();

        eventBus.register(keybindHandler);
        eventBus.register(notifications);
        eventBus.register(soundPlayer);
        eventBus.register(rotationManager);
        eventBus.register(rotationController);
        eventBus.register(spinAttackController);
        eventBus.register(mouseSimulator);
        eventBus.register(keySimulator);
        eventBus.register(new SwapScheduler());
        eventBus.register(new ReceivedPacketQueue());
        eventBus.register(new SentPacketQueue());
        eventBus.registerStatic(TickFastForward.class);
        eventBus.registerStatic(TargetManager.class);
        eventBus.registerStatic(CrashReporter.class);

        ModuleManager.INSTANCE.registerModules();
        eventBus.register(ModuleManager.INSTANCE);
        ApiClient.INSTANCE.start();
        ApiClient.INSTANCE.loadSettings();
        LOGGER.info("{} loaded {} modules", NAME, ModuleManager.INSTANCE.getModules().size());
    }

    public static void sendSilentPacket(Packet<?> packet) {
        if (mc.getNetworkHandler() == null) {
            return;
        }
        silentPackets.add(packet);
        mc.getNetworkHandler().sendPacket(packet);
    }

    public static String getCommandPrefix() {
        return COMMAND_PREFIX;
    }

    public static SSClient getInstance() {
        return instance;
    }

    public static HudLayout getHudLayout() {
        return instance.hudLayout;
    }

    public static RotationManager getRotationManager() {
        return instance.rotationManager;
    }

    public static SmoothRotationController getRotationController() {
        return instance.rotationController;
    }

    public static NotificationManager getNotifications() {
        return instance.notifications;
    }

    public static SoundPlayer getSoundPlayer() {
        return instance.soundPlayer;
    }

    public static PlayerTargetUtil getPlayerTargets() {
        return instance.playerTargets;
    }

    public static ScriptManager getScriptManager() {
        return instance.scriptManager;
    }

    public static MediaController getMediaController() {
        return instance.mediaController;
    }

    public static ReleaseNotes getReleaseNotes() {
        return instance.releaseNotes;
    }

    public static SpinAttackController getSpinAttackController() {
        return instance.spinAttackController;
    }

    public static MouseSimulator getMouseSimulator() {
        return instance.mouseSimulator;
    }

    public static KeySimulator getKeySimulator() {
        return instance.keySimulator;
    }
}
