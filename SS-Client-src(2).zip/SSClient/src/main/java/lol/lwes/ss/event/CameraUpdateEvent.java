package lol.lwes.ss.event;

public class CameraUpdateEvent extends Event {
}
