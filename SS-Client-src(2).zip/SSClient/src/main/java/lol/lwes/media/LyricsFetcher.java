package lol.lwes.media;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LyricsFetcher {
    private static final String BASE_URL = "https://lrclib.net/api";
    private static final Pattern LRC_PATTERN = Pattern.compile("\\[(\\d{2}):(\\d{2})\\.(\\d{2,3})](.*)");
    private static final Lyrics EMPTY = new Lyrics(Collections.emptyList());
    private static final HttpClient HTTP_CLIENT = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5L)).build();
    private final Map<String, Lyrics> cache = new ConcurrentHashMap<>();
    private final Set<String> pending = ConcurrentHashMap.newKeySet();
    private volatile Lyrics current;
    private volatile String currentKey = "";

    public Lyrics getCurrent() {
        return this.current;
    }

    public boolean isLoading() {
        return !this.pending.isEmpty() && this.current == null;
    }

    public void clearCache() {
        this.cache.clear();
    }

    public void update(String artist, String title) {
        if (title == null || title.isEmpty()) {
            this.current = null;
            this.currentKey = "";
            return;
        }
        String key = (artist + "|" + title).toLowerCase(Locale.ROOT);
        if (key.equals(this.currentKey)) {
            return;
        }
        this.currentKey = key;
        Lyrics cached = this.cache.get(key);
        if (cached != null) {
            this.current = cached;
            return;
        }
        if (!this.pending.add(key)) {
            return;
        }
        this.current = null;
        CompletableFuture.runAsync(() -> {
            try {
                Lyrics lyrics = this.fetchLyrics(artist, title);
                this.cache.put(key, lyrics);
                if (key.equals(this.currentKey)) {
                    this.current = lyrics;
                }
            } catch (Exception e) {
                this.cache.put(key, EMPTY);
            } finally {
                this.pending.remove(key);
            }
        });
    }

    private Lyrics fetchLyrics(String artist, String title) throws Exception {
        Lyrics exact = this.fetchExact(artist, title);
        if (exact != null && !exact.isEmpty()) {
            return exact;
        }
        return this.searchLyrics(artist, title);
    }

    private Lyrics fetchExact(String artist, String title) throws Exception {
        HttpResponse<String> response = this.httpGet(BASE_URL + "/get?artist_name=" + urlEncode(artist) + "&track_name=" + urlEncode(title));
        if (response.statusCode() != 200) {
            return null;
        }
        return this.parseLyrics(response.body());
    }

    private Lyrics searchLyrics(String artist, String title) throws Exception {
        String query = artist.isEmpty() ? title : artist + " " + title;
        HttpResponse<String> response = this.httpGet(BASE_URL + "/search?q=" + urlEncode(query));
        if (response.statusCode() != 200) {
            return EMPTY;
        }
        for (JsonElement element : JsonParser.parseString(response.body()).getAsJsonArray()) {
            JsonObject entry = element.getAsJsonObject();
            if (!entry.has("syncedLyrics") || entry.get("syncedLyrics").isJsonNull()) {
                continue;
            }
            List<LyricLine> lines = parseLrc(entry.get("syncedLyrics").getAsString());
            if (!lines.isEmpty()) {
                return new Lyrics(lines);
            }
        }
        return EMPTY;
    }

    private Lyrics parseLyrics(String body) {
        JsonObject json = JsonParser.parseString(body).getAsJsonObject();
        if (!json.has("syncedLyrics") || json.get("syncedLyrics").isJsonNull()) {
            return EMPTY;
        }
        return new Lyrics(parseLrc(json.get("syncedLyrics").getAsString()));
    }

    private HttpResponse<String> httpGet(String url) throws Exception {
        HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).header("User-Agent", "SS/1.0").GET().build();
        return HTTP_CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
    }

    private static String urlEncode(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    static List<LyricLine> parseLrc(String lrc) {
        List<LyricLine> lines = new ArrayList<>();
        for (String raw : lrc.split("\n")) {
            Matcher matcher = LRC_PATTERN.matcher(raw.trim());
            if (!matcher.matches()) {
                continue;
            }
            long minutes = Long.parseLong(matcher.group(1));
            long seconds = Long.parseLong(matcher.group(2));
            String fraction = matcher.group(3);
            long millis = Long.parseLong(fraction);
            if (fraction.length() == 2) {
                millis *= 10L;
            }
            String text = matcher.group(4).trim();
            if (!text.isEmpty()) {
                lines.add(new LyricLine(minutes * 60000L + seconds * 1000L + millis, text));
            }
        }
        Collections.sort(lines);
        return lines;
    }
}
