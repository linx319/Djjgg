package dev.prestigeclient.renderlib.api.font;

public interface RLFontEffect {
    int getColorFor(int i, double d0);
}
