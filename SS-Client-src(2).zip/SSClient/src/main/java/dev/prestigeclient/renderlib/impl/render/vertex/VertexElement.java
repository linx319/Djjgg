package dev.prestigeclient.renderlib.impl.render.vertex;

public record VertexElement(int count, int type, int typeSize, boolean normalized) {
}
