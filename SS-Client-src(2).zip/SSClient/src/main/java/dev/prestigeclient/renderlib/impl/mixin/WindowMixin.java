package dev.prestigeclient.renderlib.impl.mixin;

import net.minecraft.client.util.Window;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Window.class)
public abstract class WindowMixin {
    @Inject(method = "<init>", at = @At("HEAD"))
    private static void enableDebugContext(CallbackInfo callbackinfo) {
    }
}
